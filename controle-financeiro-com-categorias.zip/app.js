/* ===========================================================
   Controle Financeiro — lógica principal
   Armazenamento: IndexedDB (com cache em memória síncrona,
   necessário para funcionar corretamente como PWA instalado).
=========================================================== */

const DB_NAME = "controle-financeiro-db";
const DB_VERSION = 1;
const STORE = "state";
const STATE_KEY = "app-state";

const MESES = ["janeiro","fevereiro","março","abril","maio","junho","julho","agosto","setembro","outubro","novembro","dezembro"];

const GROUP_COLORS = ["#e8a0bb", "#b39ddb", "#e0c097", "#e8918a", "#8fc9d6", "#c9b3e8", "#9ed6b0", "#e8c1e0"];

let newGroupFormColor = GROUP_COLORS[0]; // cor selecionada no formulário de novo grupo (aba Editar)

let db = null;
let cache = null; // in-memory mirror of state, always source of truth for rendering
let current = new Date();
let currentYM = ymKey(current);
let activeTab = "tab-dashboard";

function ymKey(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
}

function uid() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4);
}

function groupColor(group, idx) {
  if (group && group.color) return group.color;
  return GROUP_COLORS[idx % GROUP_COLORS.length];
}

function defaultState() {
  return {
    groups: [],           // [{id, name, isCard}]
    items: [],             // [{id, groupId, name, type, fixedValue?, card?, installmentValue?, totalValue?, installments?, startYm?, dataLanc?, diaVenc?, categoryId?}]
    categories: [],         // [{id, name, color}]
    monthlyValues: {},     // { "itemId|YYYY-MM": number }  (overrides for tipo variável/fixo/parcelado)
    monthlyIncome: {},     // { "YYYY-MM": number }
    extraIncome: {},       // { "YYYY-MM": [{id, desc, value}] }
    seeded: false           // whether the starter groups have been created yet
  };
}

/* O app deve abrir zerado para um usuário novo — sem nenhum grupo,
   categoria ou item pré-criado. A configuração inicial é 100% dele,
   feita pelo botão "+" na barra de baixo. */
const STARTER_GROUPS = [];

function seedStarterGroups() {
  STARTER_GROUPS.forEach((g) => {
    const groupId = uid();
    cache.groups.push({ id: groupId, name: g.name, isCard: !!g.isCard });
    (g.items || []).forEach((itemName) => {
      cache.items.push({ id: uid(), groupId, name: itemName, type: "variavel", dataLanc: new Date().toISOString() });
    });
  });
  cache.seeded = true;
}

/* ---------------- IndexedDB layer ---------------- */

function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = (e) => {
      const _db = e.target.result;
      if (!_db.objectStoreNames.contains(STORE)) {
        _db.createObjectStore(STORE);
      }
    };
    req.onsuccess = (e) => resolve(e.target.result);
    req.onerror = (e) => reject(e);
  });
}

function loadState() {
  return new Promise((resolve) => {
    const tx = db.transaction(STORE, "readonly");
    const store = tx.objectStore(STORE);
    const req = store.get(STATE_KEY);
    req.onsuccess = () => {
      resolve(req.result || defaultState());
    };
    req.onerror = () => resolve(defaultState());
  });
}

function persist() {
  if (!db) return;
  const tx = db.transaction(STORE, "readwrite");
  tx.objectStore(STORE).put(cache, STATE_KEY);
}

/* ---------------- Helpers ---------------- */

function fmtMoney(n) {
  n = Number(n) || 0;
  return n.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function fmtMonthLabel(d) {
  const m = MESES[d.getMonth()];
  return `${m.charAt(0).toUpperCase() + m.slice(1)} ${d.getFullYear()}`;
}

function fmtDate(iso) {
  if (!iso) return "";
  const d = new Date(iso);
  if (isNaN(d.getTime())) return "";
  return d.toLocaleDateString("pt-BR");
}

function findItem(itemId) {
  return cache.items.find((i) => i.id === itemId);
}

function monthDiff(ymA, ymB) {
  const [ya, ma] = ymA.split("-").map(Number);
  const [yb, mb] = ymB.split("-").map(Number);
  return (ya - yb) * 12 + (ma - mb);
}

/* Parcelamento pelo valor total da compra: divide em centavos inteiros
   e manda a sobra de centavos para a 1ª parcela.
   Ex.: 1000 em 3x => 333,34 + 333,33 + 333,33 (soma = 1000,00). */
function parcSchedule(total, n) {
  const t = Math.round(Number(total) * 100);
  const base = Math.floor(t / n);
  const resto = t - base * n;
  return { base: base / 100, first: (base + resto) / 100, rest: resto > 0 };
}

// idx é o índice da parcela em base 0 (0 = primeira parcela)
function parcValue(total, n, idx) {
  const s = parcSchedule(total, n);
  return idx === 0 ? s.first : s.base;
}

function parcPreviewText(total, n) {
  if (!(Number(total) > 0) || !n || n < 2) {
    return "Digite o valor total da compra e o nº de parcelas — o app calcula cada parcela.";
  }
  const s = parcSchedule(total, n);
  return s.rest
    ? `1ª parcela ${fmtMoney(s.first)} + ${n - 1}× de ${fmtMoney(s.base)}`
    : `${n}× de ${fmtMoney(s.base)}`;
}

/* getValue lida com os 3 tipos de item:
   - variavel: valor lançado mês a mês (comportamento original)
   - fixo: repete um valor padrão todo mês, mas pode ser sobrescrito num mês específico
   - parcelado: calculado a partir do valor total da compra e do nº de parcelas,
     com a sobra de centavos na 1ª parcela; cada mês pode ser ajustado manualmente
     (ex.: a fatura veio diferente) sem afetar os outros meses */
function getValue(itemId, ym) {
  const item = findItem(itemId);
  if (!item) return null;

  if (item.type === "parcelado") {
    if (!item.startYm || !item.installments) return null;
    const idx = monthDiff(ym, item.startYm);
    if (idx < 0 || idx >= Number(item.installments)) return null;

    const override = cache.monthlyValues[`${itemId}|${ym}`];
    if (override !== undefined && override !== null && override !== "") {
      return Number(override);
    }

    if (item.totalValue !== undefined && item.totalValue !== null && item.totalValue !== "") {
      return parcValue(Number(item.totalValue), Number(item.installments), idx);
    }
    // item parcelado antigo (sem valorTotal): mantém o comportamento anterior
    return Number(item.installmentValue) || 0;
  }

  const override = cache.monthlyValues[`${itemId}|${ym}`];
  if (override !== undefined && override !== null && override !== "") {
    return Number(override);
  }

  if (item.type === "fixo" && item.fixedValue !== undefined && item.fixedValue !== null && item.fixedValue !== "") {
    return Number(item.fixedValue);
  }

  return null;
}

function setValue(itemId, ym, val) {
  const key = `${itemId}|${ym}`;
  if (val === "" || val === null || isNaN(val)) {
    delete cache.monthlyValues[key];
  } else {
    cache.monthlyValues[key] = Number(val);
  }
  persist();
}

function groupTotal(groupId, ym) {
  return cache.items
    .filter((it) => it.groupId === groupId)
    .reduce((sum, it) => sum + (getValue(it.id, ym) || 0), 0);
}

function monthExpenseTotal(ym) {
  return cache.items.reduce((sum, it) => sum + (getValue(it.id, ym) || 0), 0);
}

function monthIncomeTotal(ym) {
  const base = Number(cache.monthlyIncome[ym]) || 0;
  const extras = (cache.extraIncome[ym] || []).reduce((s, e) => s + Number(e.value || 0), 0);
  return base + extras;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str;
  return div.innerHTML;
}

/* ---------------- Rendering: shared ---------------- */

function render() {
  currentYM = ymKey(current);
  document.getElementById("monthLabel").textContent = fmtMonthLabel(current);

  renderNav();
  renderGroupPanels();
  renderDashboard();
  renderEditTab();
  applyActiveTab();
}

function applyActiveTab() {
  // if the active tab no longer exists (group deleted), fall back to dashboard
  const exists = document.getElementById(activeTab);
  if (!exists) activeTab = "tab-dashboard";

  document.querySelectorAll(".tab-panel").forEach((p) => {
    p.classList.toggle("active", p.id === activeTab);
  });
  document.querySelectorAll(".nav-btn").forEach((b) => {
    b.classList.toggle("active", b.getAttribute("data-tab") === activeTab);
  });
}

function switchTab(tabId) {
  activeTab = tabId;
  applyActiveTab();
  window.scrollTo({ top: 0, behavior: "instant" });
}

/* ---------------- Rendering: bottom nav ---------------- */

function renderNav() {
  const nav = document.getElementById("bottomNav");
  nav.innerHTML = "";

  const home = document.createElement("button");
  home.className = "nav-btn";
  home.setAttribute("data-tab", "tab-dashboard");
  home.innerHTML = `<span class="nav-icon">⌂</span><span class="nav-label">Início</span>`;
  home.addEventListener("click", () => switchTab("tab-dashboard"));
  nav.appendChild(home);

  cache.groups.forEach((g, idx) => {
    const btn = document.createElement("button");
    btn.className = "nav-btn";
    btn.setAttribute("data-tab", `group-${g.id}`);
    const label = g.name.length > 10 ? g.name.slice(0, 9) + "…" : g.name;
    btn.innerHTML = `<span class="nav-dot" style="background:${groupColor(g, idx)}"></span><span class="nav-label">${escapeHtml(label)}</span>`;
    btn.addEventListener("click", () => switchTab(`group-${g.id}`));
    nav.appendChild(btn);
  });

  const editBtn = document.createElement("button");
  editBtn.className = "nav-btn";
  editBtn.setAttribute("data-tab", "tab-edit");
  editBtn.innerHTML = `<span class="nav-icon">⚙</span><span class="nav-label">Editar</span>`;
  editBtn.addEventListener("click", () => switchTab("tab-edit"));
  nav.appendChild(editBtn);
}

/* ---------------- Rendering: dashboard ---------------- */

function renderDashboard() {
  const income = monthIncomeTotal(currentYM);
  const expense = monthExpenseTotal(currentYM);
  const saldo = income - expense;

  const heroVal = document.getElementById("heroValue");
  heroVal.textContent = fmtMoney(saldo);
  heroVal.className = "hero-value display " + (saldo < 0 ? "negative" : "positive");

  document.getElementById("incomeTotalDisplay").textContent = fmtMoney(income);
  document.getElementById("expenseTotalDisplay").textContent = fmtMoney(expense);

  const incomeInput = document.getElementById("monthlyIncomeInput");
  if (document.activeElement !== incomeInput) {
    const baseIncome = cache.monthlyIncome[currentYM];
    incomeInput.value = baseIncome === undefined ? "" : baseIncome;
  }

  renderExtras();
  renderDonut(expense);
  renderGroupCards();
  renderHistory();
}

function renderExtras() {
  const list = document.getElementById("extraList");
  list.innerHTML = "";
  const extras = cache.extraIncome[currentYM] || [];
  extras.forEach((ex) => {
    const row = document.createElement("div");
    row.className = "extra-item";
    row.innerHTML = `
      <span class="desc">${escapeHtml(ex.desc)}</span>
      <span class="val">${fmtMoney(ex.value)}</span>
      <button class="tiny-x" data-extra="${ex.id}" aria-label="Remover">✕</button>
    `;
    list.appendChild(row);
  });
  list.querySelectorAll("[data-extra]").forEach((btn) => {
    btn.addEventListener("click", () => {
      const id = btn.getAttribute("data-extra");
      cache.extraIncome[currentYM] = (cache.extraIncome[currentYM] || []).filter((e) => e.id !== id);
      persist();
      renderDashboard();
      toast("Entrada removida");
    });
  });
}

function renderDonut(expenseTotal) {
  const wrap = document.getElementById("donutWrap");
  wrap.innerHTML = "";

  const data = cache.groups
    .map((g, idx) => ({ name: g.name, total: groupTotal(g.id, currentYM), color: groupColor(g, idx) }))
    .filter((g) => g.total > 0)
    .sort((a, b) => b.total - a.total);

  if (data.length === 0) {
    wrap.innerHTML = `<p class="empty-hint">Nenhum gasto lançado neste mês ainda.</p>`;
    return;
  }

  let acc = 0;
  const stops = data.map((g) => {
    const pct = (g.total / expenseTotal) * 100;
    const start = acc;
    acc += pct;
    return `${g.color} ${start}% ${acc}%`;
  }).join(", ");

  const row = document.createElement("div");
  row.className = "donut-row";
  row.innerHTML = `
    <div class="donut" style="background:conic-gradient(${stops})">
      <div class="donut-hole">
        <span class="dh-label">Total</span>
        <span class="dh-value">${fmtMoney(expenseTotal)}</span>
      </div>
    </div>
    <div class="donut-legend">
      ${data.map((g) => `
        <div class="legend-row">
          <span class="legend-dot" style="background:${g.color}"></span>
          <span class="legend-name">${escapeHtml(g.name)}</span>
          <span class="legend-pct">${((g.total / expenseTotal) * 100).toFixed(0)}%</span>
        </div>
      `).join("")}
    </div>
  `;
  wrap.appendChild(row);
}

function renderGroupCards() {
  const wrap = document.getElementById("groupCardsWrap");
  wrap.innerHTML = "";

  if (cache.groups.length === 0) {
    wrap.innerHTML = `<p class="empty-hint">Nenhum grupo criado ainda. Toque em "+" na barra de baixo.</p>`;
    return;
  }

  cache.groups.forEach((g, idx) => {
    const total = groupTotal(g.id, currentYM);
    const card = document.createElement("button");
    card.className = "group-mini-card";
    card.innerHTML = `
      <div class="gm-name"><span class="nav-dot" style="background:${groupColor(g, idx)};margin:0;"></span>${escapeHtml(g.name)}</div>
      <div class="gm-value">${fmtMoney(total)}</div>
    `;
    card.addEventListener("click", () => switchTab(`group-${g.id}`));
    wrap.appendChild(card);
  });
}

function renderHistory() {
  const wrap = document.getElementById("historyWrap");
  wrap.innerHTML = "";

  /* Antes, os meses do histórico eram descobertos varrendo apenas chaves
     já salvas (renda, extras, lançamentos). Isso deixava de fora meses em
     que a única movimentação era um item fixo ou parcelado (calculados na
     hora, sem gravar chave nenhuma) — por isso o gasto "sumia" do
     histórico em meses futuros. Agora o período é sempre os 6 meses
     terminando no mês atual, calculados diretamente pela data, então
     fixos e parcelados aparecem corretamente. */
  const sorted = [];
  for (let i = 0; i < 6; i++) {
    const d = new Date(current.getFullYear(), current.getMonth() - i, 1);
    sorted.push(ymKey(d));
  }

  sorted.forEach((ym) => {
    const [y, m] = ym.split("-").map(Number);
    const saldo = monthIncomeTotal(ym) - monthExpenseTotal(ym);
    const row = document.createElement("div");
    row.className = "history-row";
    row.innerHTML = `
      <span class="hm">${MESES[m - 1]} de ${y}</span>
      <span class="hv ${saldo < 0 ? "negative" : "positive"}">${fmtMoney(saldo)}</span>
    `;
    wrap.appendChild(row);
  });
}

/* ---------------- Rendering: group tab panels ---------------- */

function renderGroupPanels() {
  const wrap = document.getElementById("groupPanelsWrap");
  wrap.innerHTML = "";

  cache.groups.forEach((g, idx) => {
    const items = cache.items.filter((it) => it.groupId === g.id);
    const total = groupTotal(g.id, currentYM);

    const panel = document.createElement("section");
    panel.className = "tab-panel";
    panel.id = `group-${g.id}`;

    panel.innerHTML = `
      <div class="group-panel-header">
        <span class="gph-title"><span class="nav-dot" style="background:${groupColor(g, idx)};margin:0;"></span>${escapeHtml(g.name)}</span>
        <span class="gph-total">${fmtMoney(total)}</span>
      </div>
      <div class="group-panel-actions">
        <button class="link-btn" data-rename="${g.id}">renomear grupo</button>
        <button class="link-btn" data-delete-group="${g.id}" style="color:var(--coral);">excluir grupo</button>
      </div>
      <div class="card">
        <div id="items-${g.id}"></div>
        <button class="link-btn" data-add-item="${g.id}">+ ${g.isCard ? "adicionar compra" : "adicionar item"}</button>
      </div>
    `;

    wrap.appendChild(panel);

    const itemsWrap = panel.querySelector(`#items-${g.id}`);
    if (items.length === 0) {
      itemsWrap.innerHTML = `<p class="empty-hint">${g.isCard ? "Nenhuma compra lançada neste cartão ainda." : "Sem itens neste grupo ainda."}</p>`;
    } else {
      items.forEach((it) => {
        const val = getValue(it.id, currentYM);
        const row = document.createElement("div");
        row.className = "item-row item-row-rich";

        const tags = [];
        if (g.isCard && it.card) tags.push(`<span class="item-tag tag-card">${escapeHtml(it.card)}</span>`);
        if (it.type === "fixo") tags.push(`<span class="item-tag tag-fixo">fixo</span>`);
        if (it.type === "parcelado") {
          const idx = it.startYm ? monthDiff(currentYM, it.startYm) : -1;
          const label = (idx >= 0 && idx < it.installments) ? `${idx + 1}/${it.installments}` : `${it.installments}x`;
          tags.push(`<span class="item-tag tag-parcelado">parcela ${label}</span>`);
        }
        if (it.categoryId) {
          const cat = cache.categories.find((c) => c.id === it.categoryId);
          if (cat) tags.push(`<span class="item-tag" style="background:${cat.color}2e;color:${cat.color};">${escapeHtml(cat.name)}</span>`);
        }

        let dateLabel = "";
        if (it.type === "fixo" && it.diaVenc) {
          dateLabel = `Vence dia ${String(it.diaVenc).padStart(2, "0")}`;
        } else if (it.type === "parcelado" && it.totalValue !== undefined && it.totalValue !== null && it.totalValue !== "") {
          dateLabel = `Compra de ${fmtMoney(it.totalValue)}` + (it.dataLanc ? ` · ${fmtDate(it.dataLanc)}` : "");
        } else if (it.dataLanc) {
          dateLabel = `Registrado em ${fmtDate(it.dataLanc)}`;
        }
        const dateHtml = dateLabel ? `<span class="item-date">${dateLabel}</span>` : "";

        const nameCol = `
          <button class="iname-btn" data-edit-item="${it.id}">
            <span class="iname">${escapeHtml(it.name)}</span>
            ${tags.length ? `<span class="item-tags">${tags.join("")}</span>` : ""}
            ${dateHtml}
          </button>
        `;

        let valueCol;
        if (it.type === "parcelado") {
          valueCol = `<span class="ival-static ${val === null ? "muted" : ""}">${val === null ? "—" : fmtMoney(val)}</span>`;
        } else {
          valueCol = `
            <span class="ival-wrap">
              <input type="number" inputmode="decimal" placeholder="${it.type === "fixo" && it.fixedValue ? Number(it.fixedValue).toFixed(2) : "0,00"}" step="0.01"
                value="${val === null ? "" : val}" data-item="${it.id}">
            </span>
          `;
        }

        row.innerHTML = `
          ${nameCol}
          ${valueCol}
          <button class="tiny-x" data-del-item="${it.id}" aria-label="Remover item">✕</button>
        `;
        itemsWrap.appendChild(row);
      });
    }

    panel.querySelectorAll("input[data-item]").forEach((inp) => {
      inp.addEventListener("input", () => {
        setValue(inp.getAttribute("data-item"), currentYM, inp.value);
        updateTotalsLive();
      });
    });
    panel.querySelectorAll("[data-del-item]").forEach((btn) => {
      btn.addEventListener("click", () => confirmDeleteItem(btn.getAttribute("data-del-item")));
    });
    panel.querySelectorAll("[data-edit-item]").forEach((btn) => {
      btn.addEventListener("click", () => openItemModal(g.id, btn.getAttribute("data-edit-item")));
    });
    panel.querySelector("[data-add-item]").addEventListener("click", () => openItemModal(g.id));
    panel.querySelector("[data-rename]").addEventListener("click", () => openRenameGroupModal(g.id));
    panel.querySelector("[data-delete-group]").addEventListener("click", () => confirmDeleteGroup(g.id));
  });
}

function updateTotalsLive() {
  // lightweight refresh of numbers without losing input focus
  const income = monthIncomeTotal(currentYM);
  const expense = monthExpenseTotal(currentYM);
  const saldo = income - expense;
  const heroVal = document.getElementById("heroValue");
  heroVal.textContent = fmtMoney(saldo);
  heroVal.className = "hero-value display " + (saldo < 0 ? "negative" : "positive");
  document.getElementById("expenseTotalDisplay").textContent = fmtMoney(expense);

  cache.groups.forEach((g) => {
    const panel = document.getElementById(`group-${g.id}`);
    if (panel) {
      const totalEl = panel.querySelector(".gph-total");
      if (totalEl) totalEl.textContent = fmtMoney(groupTotal(g.id, currentYM));
    }
  });

  renderDonut(expense);
  renderGroupCards();
}

/* ---------------- Toast ---------------- */

let toastTimer = null;
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => el.classList.remove("show"), 2200);
}

/* ---------------- Modals ---------------- */

function openModal(title, fieldsHtml, onConfirm, opts = {}) {
  const backdrop = document.getElementById("modalBackdrop");
  const box = document.getElementById("modalBox");
  box.innerHTML = `
    <h3>${title}</h3>
    <div id="modalFields">${fieldsHtml}</div>
    <div class="modal-actions">
      <button class="modal-cancel" id="modalCancelBtn">Cancelar</button>
      <button class="modal-confirm ${opts.danger ? "modal-danger" : ""}" id="modalConfirmBtn">${opts.confirmLabel || "Salvar"}</button>
    </div>
  `;
  backdrop.classList.add("open");

  const close = () => backdrop.classList.remove("open");
  document.getElementById("modalCancelBtn").onclick = close;
  document.getElementById("modalConfirmBtn").onclick = () => {
    const ok = onConfirm();
    if (ok !== false) close();
  };
  backdrop.onclick = (e) => { if (e.target === backdrop) close(); };

  setTimeout(() => {
    const firstInput = box.querySelector("input");
    if (firstInput) firstInput.focus();
  }, 50);
}

function openRenameGroupModal(groupId) {
  const g = cache.groups.find((x) => x.id === groupId);
  if (!g) return;
  openModal(
    "Editar grupo",
    `<div class="field"><label>Nome do grupo</label><input type="text" id="fGroupRename" value="${escapeHtml(g.name)}"></div>
     <label class="checkbox-row">
       <input type="checkbox" id="fGroupRenameIsCard" ${g.isCard ? "checked" : ""}>
       <span>Este grupo é de cartão de crédito</span>
     </label>`,
    () => {
      const name = document.getElementById("fGroupRename").value.trim();
      if (!name) { toast("Dê um nome ao grupo"); return false; }
      g.name = name;
      g.isCard = document.getElementById("fGroupRenameIsCard").checked;
      persist();
      render();
      switchTab(`group-${groupId}`);
      toast("Grupo atualizado");
    }
  );
}

/* ---------------- Categorias: criar / editar / excluir ---------------- */

function colorSwatchesHtml(selected) {
  return GROUP_COLORS.map((c) => `
    <span class="color-swatch" data-color="${c}" style="display:inline-block;width:24px;height:24px;border-radius:50%;background:${c};margin:3px 5px 3px 0;cursor:pointer;border:2px solid ${c === selected ? "var(--text)" : "transparent"};"></span>
  `).join("");
}

/* Renderiza os círculos de cor num container e liga os cliques,
   religando de novo a cada escolha (já que o HTML é substituído). */
function renderCatSwatches(containerId, getSelected, onPick) {
  const container = document.getElementById(containerId);
  if (!container) return;
  container.innerHTML = colorSwatchesHtml(getSelected());
  container.querySelectorAll("[data-color]").forEach((sw) => {
    sw.addEventListener("click", () => {
      onPick(sw.getAttribute("data-color"));
      renderCatSwatches(containerId, getSelected, onPick);
    });
  });
}

function categoryRowsHtml() {
  if (!cache.categories.length) {
    return `<p class="empty-hint" style="margin:0 0 14px;">Nenhuma categoria criada ainda.</p>`;
  }
  return cache.categories.map((c) => `
    <div class="item-row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);">
      <span class="iname" style="display:flex;align-items:center;gap:8px;color:var(--text);white-space:normal;">
        <span style="width:9px;height:9px;border-radius:50%;background:${c.color};display:inline-block;flex-shrink:0;"></span>
        ${escapeHtml(c.name)}
      </span>
      <span style="display:flex;gap:4px;flex-shrink:0;">
        <button type="button" class="link-btn" data-edit-cat="${c.id}" style="padding:2px 8px;">editar</button>
        <button type="button" class="link-btn" data-del-cat="${c.id}" style="padding:2px 8px;color:var(--coral);">excluir</button>
      </span>
    </div>
  `).join("");
}

/* Liga os botões editar/excluir de uma lista de categorias já inserida no DOM
   (usado tanto pela aba Editar quanto, se precisar, por qualquer outro lugar). */
function wireCatRowEvents(containerEl) {
  if (!containerEl) return;
  containerEl.querySelectorAll("[data-edit-cat]").forEach((btn) => {
    btn.addEventListener("click", () => openRenameCategoryModal(btn.getAttribute("data-edit-cat")));
  });
  containerEl.querySelectorAll("[data-del-cat]").forEach((btn) => {
    btn.addEventListener("click", () => confirmDeleteCategory(btn.getAttribute("data-del-cat")));
  });
}

function openNewCategoryModal() {
  let localColor = GROUP_COLORS[cache.categories.length % GROUP_COLORS.length];
  openModal(
    "Nova categoria",
    `<div class="field"><label>Nome</label><input type="text" id="fNewCatName" placeholder="Ex: Farmácia, Mercado..."></div>
     <div class="field"><label>Cor</label><div id="newCatColorSwatches"></div></div>`,
    () => {
      const name = document.getElementById("fNewCatName").value.trim();
      if (!name) { toast("Dê um nome à categoria"); return false; }
      cache.categories.push({ id: uid(), name, color: localColor });
      persist();
      render();
      toast("Categoria criada");
    },
    { confirmLabel: "Criar categoria" }
  );
  renderCatSwatches("newCatColorSwatches", () => localColor, (c) => { localColor = c; });
}


/* ---------------- Aba Editar: grupos + categorias, listados inline ---------------- */

function editGroupRowsHtml() {
  if (!cache.groups.length) {
    return `<p class="empty-hint" style="margin:0 0 14px;">Nenhum grupo criado ainda.</p>`;
  }
  return cache.groups.map((g, idx) => {
    const count = cache.items.filter((it) => it.groupId === g.id).length;
    return `
    <div class="item-row" style="justify-content:space-between;padding:9px 0;border-bottom:1px solid var(--border);">
      <span class="iname" style="display:flex;align-items:center;gap:8px;color:var(--text);white-space:normal;">
        <span style="width:9px;height:9px;border-radius:50%;background:${groupColor(g, idx)};display:inline-block;flex-shrink:0;"></span>
        ${escapeHtml(g.name)}
        <span style="color:var(--muted);font-size:0.78rem;">${count} ${count === 1 ? "item" : "itens"}</span>
      </span>
      <span style="display:flex;gap:4px;flex-shrink:0;">
        <button type="button" class="link-btn" data-edit-group="${g.id}" style="padding:2px 8px;">editar</button>
        <button type="button" class="link-btn" data-del-group="${g.id}" style="padding:2px 8px;color:var(--coral);">excluir</button>
      </span>
    </div>`;
  }).join("");
}

function wireEditGroupListEvents(containerEl) {
  if (!containerEl) return;
  containerEl.querySelectorAll("[data-edit-group]").forEach((btn) => {
    btn.addEventListener("click", () => openRenameGroupModal(btn.getAttribute("data-edit-group")));
  });
  containerEl.querySelectorAll("[data-del-group]").forEach((btn) => {
    btn.addEventListener("click", () => confirmDeleteGroup(btn.getAttribute("data-del-group")));
  });
}

function createGroupInline() {
  const nameInput = document.getElementById("newGroupName");
  const name = nameInput.value.trim();
  if (!name) { toast("Dê um nome ao grupo"); return; }
  const isCard = document.getElementById("newGroupIsCard").checked;
  cache.groups.push({ id: uid(), name, isCard, color: newGroupFormColor });
  persist();
  toast("Grupo criado");
  nameInput.value = "";
  document.getElementById("newGroupIsCard").checked = false;
  render();
}

/* Redesenha a aba "Editar": lista de grupos, formulário de novo grupo (com
   paleta de cores) e lista de categorias — tudo inline, sem popup, igual
   ao controle-fin-v9.html, só que com a identidade visual do app. */
function renderEditTab() {
  const groupListEl = document.getElementById("editGroupList");
  const catListEl = document.getElementById("editCatList");
  if (!groupListEl || !catListEl) return; // aba ainda não existe no DOM (defensivo)

  groupListEl.innerHTML = editGroupRowsHtml();
  wireEditGroupListEvents(groupListEl);

  catListEl.innerHTML = categoryRowsHtml();
  wireCatRowEvents(catListEl);

  renderCatSwatches("newGroupColorPicks", () => newGroupFormColor, (c) => { newGroupFormColor = c; });
}

function openRenameCategoryModal(catId) {
  const cat = cache.categories.find((c) => c.id === catId);
  if (!cat) return;
  let localColor = cat.color;
  openModal(
    "Editar categoria",
    `<div class="field"><label>Nome</label><input type="text" id="fCatRename" value="${escapeHtml(cat.name)}"></div>
     <div class="field"><label>Cor</label><div id="editCatColorSwatches"></div></div>`,
    () => {
      const name = document.getElementById("fCatRename").value.trim();
      if (!name) { toast("Dê um nome à categoria"); return false; }
      cat.name = name;
      cat.color = localColor;
      persist();
      render();
      toast("Categoria atualizada");
    },
    { confirmLabel: "Salvar" }
  );
  renderCatSwatches("editCatColorSwatches", () => localColor, (c) => { localColor = c; });
}

function confirmDeleteCategory(catId) {
  const cat = cache.categories.find((c) => c.id === catId);
  if (!cat) return;
  openModal(
    `Excluir categoria "${cat.name}"?`,
    `<p style="color:var(--muted);font-size:0.88rem;line-height:1.5;">Os itens que usam essa categoria voltam a ficar sem categoria. Essa ação não pode ser desfeita.</p>`,
    () => {
      cache.items.forEach((it) => { if (it.categoryId === catId) it.categoryId = null; });
      cache.categories = cache.categories.filter((c) => c.id !== catId);
      persist();
      render();
      toast("Categoria excluída");
    },
    { confirmLabel: "Excluir", danger: true }
  );
}

/* ---- Item modal: cobre criação e edição, com os 3 tipos e o campo de cartão ---- */

function monthLabelFromYm(ym) {
  const [y, m] = ym.split("-").map(Number);
  return `${MESES[m - 1]} de ${y}`;
}

/* editMode só importa para tipo "parcelado" ao EDITAR um item que já era parcelado:
   "compra" = recalcula as parcelas a partir do valor total; "parcela" = ajusta só o mês atual. */
function typeFieldsHtml(type, existing, editMode) {
  if (type === "fixo") {
    return `<div class="field"><label>Valor fixo mensal</label><input type="number" step="0.01" id="fItemFixed" placeholder="0,00" value="${existing && existing.fixedValue != null ? existing.fixedValue : ""}"></div>
      <p class="empty-hint" style="margin-top:-6px;">Esse valor se repete todo mês sozinho. Dá pra mudar em um mês específico direto na lista, sem afetar os outros.</p>
      <div class="field"><label>Dia de vencimento</label><input type="number" min="1" max="31" step="1" id="fItemVenc" placeholder="Ex: 10" value="${existing && existing.diaVenc != null ? existing.diaVenc : ""}"></div>`;
  }

  if (type === "parcelado") {
    const isEditingParcelado = !!(existing && existing.type === "parcelado");
    const soParcela = isEditingParcelado && editMode === "parcela";

    const editModoField = isEditingParcelado ? `
      <div class="field">
        <label>O que alterar?</label>
        <select id="fItemEditModo">
          <option value="compra"${editMode !== "parcela" ? " selected" : ""}>Compra inteira (recalcula as parcelas)</option>
          <option value="parcela"${editMode === "parcela" ? " selected" : ""}>Só esta parcela (${monthLabelFromYm(currentYM)})</option>
        </select>
      </div>
    ` : "";

    if (soParcela) {
      const currentVal = getValue(existing.id, currentYM);
      return `${editModoField}
        <div class="field"><label>Valor desta parcela (R$)</label><input type="number" step="0.01" id="fItemInstallVal" placeholder="0,00" value="${currentVal === null ? "" : currentVal}"></div>
        <p class="empty-hint" style="margin-top:-6px;">Ajusta só o mês de ${monthLabelFromYm(currentYM)} (ex.: a fatura veio diferente). Os outros meses continuam como estavam.</p>`;
    }

    // modo "compra inteira" (item novo, ou editando a compra toda)
    let prefillTotal = "";
    if (existing) {
      if (existing.totalValue !== undefined && existing.totalValue !== null && existing.totalValue !== "") {
        prefillTotal = existing.totalValue;
      } else if (existing.installmentValue != null && existing.installments) {
        // item parcelado antigo sem valorTotal: mostra valor×parcelas (round-trip estável)
        prefillTotal = Math.round(Number(existing.installmentValue) * Number(existing.installments) * 100) / 100;
      }
    }
    const prefillCount = existing && existing.installments ? existing.installments : "";
    return `${editModoField}
      <div class="field"><label>Valor total da compra (R$)</label><input type="number" step="0.01" id="fItemInstallVal" placeholder="0,00" value="${prefillTotal}"></div>
      <div class="field"><label>Número de parcelas</label><input type="number" min="2" max="120" step="1" id="fItemInstallCount" placeholder="Ex: 10" value="${prefillCount}"></div>
      <div id="parcPreview" class="parc-preview">${escapeHtml(parcPreviewText(prefillTotal, Number(prefillCount) || 0))}</div>`;
  }

  return `<p class="empty-hint" style="margin:0;">O valor é lançado mês a mês, direto na lista do grupo.</p>`;
}

function openItemModal(groupId, itemId) {
  const group = cache.groups.find((g) => g.id === groupId);
  if (!group) return;
  const existing = itemId ? findItem(itemId) : null;
  let selectedType = existing ? existing.type : "variavel";
  let installEditMode = "compra";

  const cardOptions = Array.from(new Set(
    cache.items.filter((i) => i.groupId === groupId && i.card).map((i) => i.card)
  ));
  const suggested = ["Santander", "Porto", "Mercado Pago", "Inter"].filter((c) => !cardOptions.includes(c));
  const allCardOptions = [...cardOptions, ...suggested];

  const cardField = group.isCard ? `
    <div class="field">
      <label>Cartão</label>
      <input type="text" id="fItemCard" list="cardSuggestions" placeholder="Ex: Santander" value="${existing && existing.card ? escapeHtml(existing.card) : ""}">
      <datalist id="cardSuggestions">
        ${allCardOptions.map((c) => `<option value="${escapeHtml(c)}">`).join("")}
      </datalist>
    </div>
  ` : "";

  const fieldsHtml = `
    <div class="field"><label>${group.isCard ? "Descrição da compra" : "Nome do item"}</label>
      <input type="text" id="fItemName" placeholder="${group.isCard ? "Ex: Notebook, Mercado..." : "Ex: Luz, Mercado, Prestação..."}" value="${existing ? escapeHtml(existing.name) : ""}"></div>
    ${cardField}
    <div class="field">
      <label>Tipo</label>
      <div class="type-toggle" id="typeToggle">
        <button type="button" class="type-opt${selectedType === "variavel" ? " active" : ""}" data-type="variavel">Variável</button>
        <button type="button" class="type-opt${selectedType === "fixo" ? " active" : ""}" data-type="fixo">Fixo</button>
        <button type="button" class="type-opt${selectedType === "parcelado" ? " active" : ""}" data-type="parcelado">Parcelado</button>
      </div>
    </div>
    <div id="typeFieldsWrap">${typeFieldsHtml(selectedType, existing, installEditMode)}</div>
    <div class="field">
      <label>Categoria <span style="color:var(--muted);font-weight:400;">(opcional)</span></label>
      <select id="fItemCategory">
        <option value="">Nenhuma</option>
        ${cache.categories.map((c) => `<option value="${c.id}" ${existing && existing.categoryId === c.id ? "selected" : ""}>${escapeHtml(c.name)}</option>`).join("")}
      </select>
    </div>
  `;

  openModal(
    existing ? "Editar item" : (group.isCard ? "Nova compra" : "Novo item"),
    fieldsHtml,
    () => {
      const name = document.getElementById("fItemName").value.trim();
      if (!name) { toast("Dê um nome"); return false; }

      const soParcela = !!existing && existing.type === "parcelado" && selectedType === "parcelado" && installEditMode === "parcela";
      const catVal = document.getElementById("fItemCategory").value;

      // Ajuste manual de UMA parcela (ex.: a fatura veio diferente): muda só o mês atual
      if (soParcela) {
        const val = parseFloat(document.getElementById("fItemInstallVal").value);
        if (isNaN(val) || val <= 0) { toast("Informe o valor desta parcela"); return false; }
        existing.name = name;
        existing.categoryId = catVal || null;
        persist();
        setValue(existing.id, currentYM, val);
        toast("Parcela ajustada só neste mês");
        render();
        switchTab(`group-${groupId}`);
        return;
      }

      if (group.isCard) {
        const card = document.getElementById("fItemCard").value.trim();
        if (!card) { toast("Diga a qual cartão pertence"); return false; }
      }

      const payload = { name, type: selectedType, categoryId: catVal || null };

      if (group.isCard) {
        payload.card = document.getElementById("fItemCard").value.trim();
      }

      let savedPreviewText = "";

      if (selectedType === "fixo") {
        const fv = parseFloat(document.getElementById("fItemFixed").value);
        payload.fixedValue = isNaN(fv) ? null : fv;
        const dv = parseInt(document.getElementById("fItemVenc").value, 10);
        if (!dv || dv < 1 || dv > 31) { toast("Informe o dia de vencimento (1-31)"); return false; }
        payload.diaVenc = dv;
        payload.totalValue = null;
        payload.installmentValue = null;
        payload.installments = null;
      } else if (selectedType === "parcelado") {
        const totalValue = parseFloat(document.getElementById("fItemInstallVal").value);
        const installments = parseInt(document.getElementById("fItemInstallCount").value, 10);
        if (isNaN(totalValue) || totalValue <= 0) { toast("Informe o valor total da compra"); return false; }
        if (isNaN(installments) || installments < 2) { toast("Informe o número de parcelas (mín. 2)"); return false; }
        if (installments > 120) { toast("Máximo de 120 parcelas"); return false; }
        payload.totalValue = totalValue;
        payload.installments = installments;
        payload.installmentValue = null; // modelo novo passa a usar totalValue + installments
        payload.startYm = (existing && existing.startYm) ? existing.startYm : currentYM;
        payload.diaVenc = null;
        savedPreviewText = parcPreviewText(totalValue, installments);
      } else {
        payload.diaVenc = null;
        payload.totalValue = null;
        payload.installmentValue = null;
        payload.installments = null;
      }

      if (existing) {
        Object.assign(existing, payload);
        toast("Item atualizado");
      } else {
        cache.items.push({ id: uid(), groupId, dataLanc: new Date().toISOString(), ...payload });
        toast(selectedType === "parcelado" ? `Compra parcelada salva! ${savedPreviewText}` : (group.isCard ? "Compra adicionada" : "Item adicionado"));
      }
      persist();
      render();
      switchTab(`group-${groupId}`);
    }
  );

  function rebuildTypeFields() {
    document.getElementById("typeFieldsWrap").innerHTML = typeFieldsHtml(selectedType, existing, installEditMode);
    attachParcListeners();
  }

  function attachParcListeners() {
    const editModoSel = document.getElementById("fItemEditModo");
    if (editModoSel) {
      editModoSel.addEventListener("change", () => {
        installEditMode = editModoSel.value;
        rebuildTypeFields();
      });
    }
    const valInput = document.getElementById("fItemInstallVal");
    const countInput = document.getElementById("fItemInstallCount");
    const preview = document.getElementById("parcPreview");
    if (valInput && countInput && preview) {
      const updatePreview = () => {
        preview.textContent = parcPreviewText(parseFloat(valInput.value), parseInt(countInput.value, 10) || 0);
      };
      valInput.addEventListener("input", updatePreview);
      countInput.addEventListener("input", updatePreview);
    }
  }

  attachParcListeners();

  document.getElementById("typeToggle").addEventListener("click", (e) => {
    const btn = e.target.closest(".type-opt");
    if (!btn) return;
    selectedType = btn.getAttribute("data-type");
    installEditMode = "compra";
    document.querySelectorAll("#typeToggle .type-opt").forEach((b) => b.classList.toggle("active", b === btn));
    rebuildTypeFields();
  });
}

function openExtraModal() {
  openModal(
    "Entrada extra",
    `<div class="field"><label>Descrição</label><input type="text" id="fExtraDesc" placeholder="Ex: Freelance, presente..."></div>
     <div class="field"><label>Valor</label><input type="number" step="0.01" id="fExtraVal" placeholder="0,00"></div>`,
    () => {
      const desc = document.getElementById("fExtraDesc").value.trim();
      const val = parseFloat(document.getElementById("fExtraVal").value);
      if (!desc || isNaN(val)) { toast("Preencha descrição e valor"); return false; }
      if (!cache.extraIncome[currentYM]) cache.extraIncome[currentYM] = [];
      cache.extraIncome[currentYM].push({ id: uid(), desc, value: val });
      persist();
      renderDashboard();
      toast("Entrada adicionada");
    }
  );
}

function confirmDeleteGroup(groupId) {
  const g = cache.groups.find((x) => x.id === groupId);
  if (!g) return;
  openModal(
    `Excluir "${g.name}"?`,
    `<p style="color:var(--muted);font-size:0.88rem;line-height:1.5;">Isso vai remover o grupo e todos os itens e valores lançados nele, em todos os meses. Essa ação não pode ser desfeita.</p>`,
    () => {
      cache.items = cache.items.filter((it) => it.groupId !== groupId);
      cache.groups = cache.groups.filter((x) => x.id !== groupId);
      const remainingIds = new Set(cache.items.map((i) => i.id));
      Object.keys(cache.monthlyValues).forEach((k) => {
        const itemId = k.split("|")[0];
        if (!remainingIds.has(itemId)) delete cache.monthlyValues[k];
      });
      persist();
      activeTab = "tab-dashboard";
      render();
      toast("Grupo excluído");
    },
    { confirmLabel: "Excluir", danger: true }
  );
}

function confirmDeleteItem(itemId) {
  const it = cache.items.find((x) => x.id === itemId);
  if (!it) return;
  cache.items = cache.items.filter((x) => x.id !== itemId);
  Object.keys(cache.monthlyValues).forEach((k) => {
    if (k.startsWith(itemId + "|")) delete cache.monthlyValues[k];
  });
  persist();
  render();
  toast("Item removido");
}

/* ---------------- Report (print) ---------------- */

function buildReport() {
  const view = document.getElementById("reportView");
  const income = monthIncomeTotal(currentYM);
  const expense = monthExpenseTotal(currentYM);
  const saldo = income - expense;
  const extras = cache.extraIncome[currentYM] || [];
  const baseIncome = Number(cache.monthlyIncome[currentYM]) || 0;

  let html = `
    <h1>Controle Financeiro</h1>
    <div class="rsub">Relatório de ${fmtMonthLabel(current)}</div>
    <table>
      <tr><th>Receita</th><th style="text-align:right">Valor</th></tr>
      <tr><td>Renda mensal</td><td style="text-align:right">${fmtMoney(baseIncome)}</td></tr>
      ${extras.map((e) => `<tr><td>${escapeHtml(e.desc)}</td><td style="text-align:right">${fmtMoney(e.value)}</td></tr>`).join("")}
      <tr class="rtotal-row"><td>Total de receita</td><td style="text-align:right">${fmtMoney(income)}</td></tr>
    </table>
  `;

  cache.groups.forEach((g) => {
    const items = cache.items.filter((it) => it.groupId === g.id);
    if (items.length === 0) return;
    const total = groupTotal(g.id, currentYM);
    html += `<div class="rgroup-title">${escapeHtml(g.name)}</div><table>`;
    items.forEach((it) => {
      const v = getValue(it.id, currentYM);
      if (v === null) return;
      html += `<tr><td>${escapeHtml(it.name)}</td><td style="text-align:right">${fmtMoney(v)}</td></tr>`;
    });
    html += `<tr class="rtotal-row"><td>Subtotal</td><td style="text-align:right">${fmtMoney(total)}</td></tr></table>`;
  });

  html += `
    <table>
      <tr class="rtotal-row"><td>Total de despesas</td><td style="text-align:right">${fmtMoney(expense)}</td></tr>
      <tr class="rtotal-row"><td>Saldo do mês</td><td style="text-align:right">${fmtMoney(saldo)}</td></tr>
    </table>
  `;

  view.innerHTML = html;
}

function exportReport() {
  buildReport();
  setTimeout(() => window.print(), 80);
}

/* ---------------- Backup / restore ---------------- */

function exportBackup() {
  const payload = {
    app: "controle-financeiro",
    exportedAt: new Date().toISOString(),
    dados: cache
  };
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `controle-financeiro-backup-${ymKey(new Date())}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  toast("Backup exportado");
}

function importBackup(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const parsed = JSON.parse(e.target.result);
      const data = parsed.dados || parsed;
      if (!data.groups || !data.items) { toast("Arquivo inválido"); return; }
      cache = Object.assign(defaultState(), data);
      persist();
      activeTab = "tab-dashboard";
      render();
      toast("Backup restaurado");
    } catch (err) {
      toast("Erro ao ler o arquivo");
    }
  };
  reader.readAsText(file);
}

/* ---------------- Navigation (months) ---------------- */

function changeMonth(delta) {
  current = new Date(current.getFullYear(), current.getMonth() + delta, 1);
  render();
}

/* ---------------- Init ---------------- */

async function init() {
  db = await openDB();
  cache = await loadState();

  // compatibilidade: quem já tinha dados salvos antes das categorias existirem
  if (!cache.categories) cache.categories = [];

  if (!cache.seeded) {
    seedStarterGroups();
    persist();
  }

  newGroupFormColor = GROUP_COLORS[cache.groups.length % GROUP_COLORS.length];

  document.getElementById("prevMonth").addEventListener("click", () => changeMonth(-1));
  document.getElementById("nextMonth").addEventListener("click", () => changeMonth(1));
  document.getElementById("createGroupBtn").addEventListener("click", createGroupInline);
  document.getElementById("newCatBtnTab").addEventListener("click", openNewCategoryModal);

  document.getElementById("monthlyIncomeInput").addEventListener("input", (e) => {
    cache.monthlyIncome[currentYM] = e.target.value === "" ? undefined : Number(e.target.value);
    persist();
    const heroVal = document.getElementById("heroValue");
    const income = monthIncomeTotal(currentYM);
    const expense = monthExpenseTotal(currentYM);
    const saldo = income - expense;
    heroVal.textContent = fmtMoney(saldo);
    heroVal.className = "hero-value display " + (saldo < 0 ? "negative" : "positive");
    document.getElementById("incomeTotalDisplay").textContent = fmtMoney(income);
  });
  document.getElementById("monthlyIncomeInput").addEventListener("blur", () => renderDashboard());

  document.getElementById("addExtraBtn").addEventListener("click", openExtraModal);
  document.getElementById("reportBtn").addEventListener("click", exportReport);
  document.getElementById("backupBtn").addEventListener("click", exportBackup);
  document.getElementById("restoreInput").addEventListener("change", (e) => {
    if (e.target.files[0]) importBackup(e.target.files[0]);
    e.target.value = "";
  });

  render();

  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("./sw.js").catch(() => {});
  }
}

init();
